**************************************************************************
**	Shadow Mapping
**
**	www.paulsprojects.net
**
**	paul@paulsprojects.net
**************************************************************************


Description:

This project accompanies a tutorial available on my site. It implements shadow mapping using ARB extensions.


Requirements:

ARB_depth_texture
ARB_shadow


References:




Keys:

F1		-	Take a screenshot
Escape	-	Quit