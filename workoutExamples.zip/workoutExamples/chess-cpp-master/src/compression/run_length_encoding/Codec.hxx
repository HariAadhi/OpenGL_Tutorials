class Codec {
public:
  void compress(string source, string destination);
  void decompress(string source, string destination);
};
