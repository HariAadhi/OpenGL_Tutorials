#ifndef _MAPPING_OF_WILDCARDS_
#define _MAPPING_OF_WILDCARDS_

#include "../typedefs.hxx"

void map_wildcards(uint8_t *bdd_table, int log_size);

void test_wildcard_mapping();

#endif
