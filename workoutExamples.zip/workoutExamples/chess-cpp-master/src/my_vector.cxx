#include "my_vector.hxx"

int num_in_existance = 0;
