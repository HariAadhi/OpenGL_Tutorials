#ifndef _ENDGAME_SIMPLE_CONSTRUCTION_
#define _ENDGAME_SIMPLE_CONSTRUCTION_

#include "endgame_database.hxx"

void build_endgame_simple(EndgameFunctionality* endgame, int8_t **table);

#endif
