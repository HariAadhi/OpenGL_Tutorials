#ifndef _ENDGAME_RETROGRADE_CONSTRUCTION_
#define _ENDGAME_RETROGRADE_CONSTRUCTION_

#include "endgame_database.hxx"

void build_endgame_retrograde(EndgameFunctionality* endgame, int8_t **table);

#endif
