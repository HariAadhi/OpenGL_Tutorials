chess-cpp
=========

Source code for the program made in my master thesis: Generation and compression of endgame tables in chess with fast random access using OBDDs.

Status for project is currently unknown, it's not well documented, etcetera.
