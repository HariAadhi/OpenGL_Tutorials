template <class TYPE>
class LocatorArray {
public:
  LocatorArray(int size) : size(size) {
    
  }

  TYPE operator[](int index) {


  }



private:
  int size;


};
